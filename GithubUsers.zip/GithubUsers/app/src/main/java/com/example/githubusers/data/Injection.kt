package com.example.githubusers.data

import android.content.Context
import com.example.githubusers.retrofit.Apiservice

object Injection {
    fun provideRepo(context: Context): Repository {
        val apiService = Apiservice.getApiService()
        return Repository.getInstance(apiService)
    }
}