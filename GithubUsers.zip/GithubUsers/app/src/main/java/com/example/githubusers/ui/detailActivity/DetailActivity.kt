package com.example.githubusers.ui.detailActivity

import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.ActionBar
import androidx.core.content.ContextCompat
import com.example.githubusers.R
import com.example.githubusers.ViewModelFactory
import com.example.githubusers.adapter.SectionsPagerAdapter
import com.example.githubusers.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayoutMediator
import com.squareup.picasso.Picasso

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel by viewModels<DetailViewModel> {
        ViewModelFactory.getInstance(this)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.color3)))

        val nama=intent.getStringExtra(NAMA)
        val sectionsPagerAdapter = SectionsPagerAdapter(this, nama)
        binding.viewPager.adapter = sectionsPagerAdapter
        TabLayoutMediator(binding.tabs, binding.viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        detailViewModel.getDetail(nama!!).observe(this){
            binding.tvUsername.text=it.login
            binding.tvName.text=it.name
            Picasso.get().load(it.avatarUrl).into(binding.imageView)
            binding.followers.text="${it.followers} Followers "
            binding.following.text="${it.following} Following "
        }
        detailViewModel.getLoading().observe(this){
            showLoading(it)
        }



    }
    private fun showLoading(it: Boolean) {
        binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
    }
    companion object {
        const val NAMA="nama"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.follower,
            R.string.following
        )
    }
}